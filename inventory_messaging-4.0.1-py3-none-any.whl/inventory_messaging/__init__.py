import os
import socket
from typing import NamedTuple, Type, Generator, Union, List
import logging
from time import sleep
import signal

from confluent_kafka import Producer, Consumer, KafkaException, KafkaError
from confluent_kafka.admin import AdminClient, NewTopic

logger = logging.getLogger(__name__)

KAFKA_HOST = os.environ.get('KAFKA_HOST', 'kafka')
KAFKA_PORT = os.environ.get('KAFKA_PORT', '9094')
KAFKA_ADDRESSES = os.environ.get('KAFKA_ADDRESS', f'{KAFKA_HOST}:{KAFKA_PORT}')
KAFKA_GROUP_ID = os.environ.get('KAFKA_GROUP_ID', 'default')
KAFKA_OFFSET = os.environ.get('KAFKA_OFFSET', 'latest')
KAFKA_SASL_USERNAME = os.environ.get('KAFKA_SASL_USERNAME')
KAFKA_SASL_PASSWORD = os.environ.get('KAFKA_SASL_PASSWORD')

__ALL__ = ['fetch_work', 'get_producer']


DEFAULT_CONF = {
    'bootstrap.servers': KAFKA_ADDRESSES,  # 'domain:port' or 'domain1:port,domain2:port,domain3:port'
    'client.id': socket.gethostname(),
    'group.id': KAFKA_GROUP_ID,
    'auto.offset.reset': KAFKA_OFFSET,
}
if KAFKA_SASL_USERNAME and KAFKA_SASL_PASSWORD:
    DEFAULT_CONF['sasl.mechanisms'] = 'SCRAM-SHA-512'
    DEFAULT_CONF['security.protocol'] = 'SASL_SSL'
    DEFAULT_CONF['sasl.username'] = KAFKA_SASL_USERNAME
    DEFAULT_CONF['sasl.password'] = KAFKA_SASL_PASSWORD

def _test_shim():
    return


def wait_for_topic(consumer: Consumer, topic: str):
    """
    Wait for the existence of the topic before proceeding.

    Parameters
    ----------
    consumer : Kafka consumer instance.

    topic : The topic to wait for.
    """
    while True:
        logger.info('checking topic existence')
        topics = consumer.list_topics().topics
        if topic not in topics:
            logger.warning(f'Topic {topic} does not exist yet, sleeping for a while')
            _test_shim()
            sleep(1)
            continue
        break


def handle_kafka_error(error, msg):
    """
    Handle the error message from Kafka.

    Parameters
    ----------
    error : Error message from Kafka.

    msg : Message from Kafka.
    """
    if error.code() == KafkaError._PARTITION_EOF:
        logger.info('%% %s [%d] reached end at offset %d\n' % (msg.topic(), msg.partition(), msg.offset()))
    elif error.code() == KafkaError._UNKNOWN_TOPIC:
        logger.info('Topic doesnt exist yet, sleeping')
        sleep(1)
    elif error:
        logger.warning(f'Error found. This is my error and I dont know what to do, so Im crashing to bring it to your attention: {error}')


def get_bare_consumer(group_id: str = None, conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
    if group_id is not None:
        conf['group.id'] = group_id
    return Consumer(conf)


def fetch_work(topic : Union[str,List[str]], serializer_class: 'Protobuf', message_type: Type[NamedTuple], group_id: str = None, consumer: Consumer = None) -> Generator[Type[NamedTuple], None, None]:
    """
    BYOSerializers: Fetches work from Kafka, deserializes it, and results in a populated local message_type NamedTuple.

    Parameters
    ----------
    serializer_class : Protobuf serializer class.

    message_type : NamedTuple subclass. Needs to have a `from_protobuf` method.
    """
    logger.info('initializing consumer')
    if consumer is None:
        consumer = get_bare_consumer(group_id=group_id)
    try:
        signal.signal(signal.SIGTERM, lambda *args: consumer.close())
        signal.signal(signal.SIGINT, lambda *args: consumer.close())
    except ValueError:
        logging.warning('Running in debug? Cannot attach singal to non-main thread of interpreter.')
    wait_for_topic(consumer, topic)

    logger.info(f'subscribing to topic: {topic}')
    if type(topic) == list:
        topics = topic
    else:
        topics = [topic]
    consumer.subscribe(topics)
    logger.info('kicking off loop')
    while True:
        try:
            msg = consumer.poll(timeout=1.0)
        except RuntimeError:
            # Already closed due to sigterm or sigint,
            # so call it quits
            break
        if msg is None:
            continue
        error = msg.error()
        if error:
            handle_kafka_error(error, msg)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            yield message_type.from_protobuf(buffer)


def get_producer(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return Producer(conf)


def get_admin_client(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return AdminClient(conf)
