import sys
import os
import socket
from typing import NamedTuple, Type, Generator
import logging
from time import sleep

from confluent_kafka import Producer, Consumer, KafkaException, KafkaError

logger = logging.getLogger(__name__)

KAFKA_HOST = os.environ.get('KAFKA_HOST', 'kafka')

__ALL__ = ['fetch_work', 'get_producer']


KAFKA_ADDRESS = f'{KAFKA_HOST}:9092'
DEFAULT_CONF = {
    'bootstrap.servers': KAFKA_ADDRESS,
    'client.id': socket.gethostname(),
    'group.id': '1',
}
BUCKET_NAME = os.environ.get('AWS_BUCKET_NAME', 'smart-storage-file-backend')


def fetch_work(topic : str, serializer_class: 'Protobuf', message_type: Type[NamedTuple]) -> Generator[Type[NamedTuple], None, None]:
    """
    BYOSerializers: Fetches work from Kafka, deserializes it, and results in a populated local message_type NamedTuple.

    Parameters
    ----------
    serializer_class : Protobuf serializer class.

    message_type : NamedTuple subclass. Needs to have a `from_protobuf` method.
    """
    logger.info('initializing consumer')
    consumer = Consumer(DEFAULT_CONF)
    logger.info(f'subscribing to topic: {topic}')
    consumer.subscribe([topic])
    logger.info('kicking off loop')
    while True:
        msg = consumer.poll(timeout=1.0)
        if msg is None:
            continue
        error = msg.error()
        if error:
            if error.code() == KafkaError._PARTITION_EOF:
                logger.info('%% %s [%d] reached end at offset %d\n' %
                                 (msg.topic(), msg.partition(), msg.offset()))
            elif error.code() == KafkaError._UNKNOWN_TOPIC:
                logger.info('Topic doesnt exist yet, sleeping')
                sleep(10)
            elif error:
                logger.warning(f'Error found. This is my error and I dont know what to do, so Im crashing to bring it to your attention: {error}')
                # raise KafkaException(error)
                sleep(10)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            yield message_type.from_protobuf(buffer)

def get_producer():
    return Producer(DEFAULT_CONF)
