import os
import json
import socket
from typing import NamedTuple, Type, Generator, Union, List, Dict, Optional, Any
import logging
from time import sleep
import signal
from dataclasses import dataclass

from confluent_kafka import Producer, Consumer, KafkaException, KafkaError, Message
from confluent_kafka.admin import AdminClient, NewTopic

# Optional boto3 import for SQS support
try:
    import boto3
    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False

logger = logging.getLogger(__name__)

KAFKA_HOST = os.environ.get('KAFKA_HOST', 'kafka')
KAFKA_PORT = os.environ.get('KAFKA_PORT', '9094')
KAFKA_ADDRESSES = os.environ.get('KAFKA_ADDRESS', f'{KAFKA_HOST}:{KAFKA_PORT}')
KAFKA_GROUP_ID = os.environ.get('KAFKA_GROUP_ID', 'default')
KAFKA_OFFSET = os.environ.get('KAFKA_OFFSET', 'latest')
KAFKA_SASL_USERNAME = os.environ.get('KAFKA_SASL_USERNAME')
KAFKA_SASL_PASSWORD = os.environ.get('KAFKA_SASL_PASSWORD')

@dataclass
class MessageContext:
    """Rich context for consumed messages with backward compatibility"""
    data: Any  # The deserialized protobuf data
    headers: Dict[str, bytes]  # Raw Kafka headers
    trace_context: Optional[Dict[str, str]] = None  # OTEL trace headers
    topic: Optional[str] = None
    partition: Optional[int] = None
    offset: Optional[int] = None
    timestamp: Optional[int] = None
    key: Optional[bytes] = None
    
    def __getattr__(self, name):
        """Backward compatibility - delegate to data object"""
        return getattr(self.data, name)
    
    def __iter__(self):
        """Support tuple unpacking for backward compatibility"""
        return iter(self.data)


def extract_headers_from_kafka_message(msg: Message) -> Dict[str, bytes]:
    """Extract headers from Kafka message as dict of bytes."""
    headers = {}
    if msg.headers():
        for key, value in msg.headers():
            if value is not None:
                headers[key] = value
    return headers


def extract_trace_context(headers: Dict[str, bytes]) -> Optional[Dict[str, str]]:
    """Extract OTEL trace context from headers."""
    trace_headers = {}
    # Common OTEL trace propagation headers
    trace_keys = ['traceparent', 'tracestate', 'baggage']
    
    for key, value in headers.items():
        if key.lower() in trace_keys:
            try:
                trace_headers[key] = value.decode('utf-8')
            except UnicodeDecodeError:
                logger.warning(f"Failed to decode trace header {key}")
    
    return trace_headers if trace_headers else None


__ALL__ = [
    # Kafka (original)
    'fetch_work', 'get_producer', 'MessageContext', 'fetch_work_with_context', 'produce_with_headers',
    # SQS (new)
    'send_message', 'fetch_work_sqs', 'fetch_work_sqs_with_context',
]


DEFAULT_CONF = {
    'bootstrap.servers': KAFKA_ADDRESSES,  # 'domain:port' or 'domain1:port,domain2:port,domain3:port'
    'client.id': socket.gethostname(),
    'group.id': KAFKA_GROUP_ID,
    'auto.offset.reset': KAFKA_OFFSET,
}
if KAFKA_SASL_USERNAME and KAFKA_SASL_PASSWORD:
    DEFAULT_CONF['sasl.mechanisms'] = 'SCRAM-SHA-512'
    DEFAULT_CONF['security.protocol'] = 'SASL_SSL'
    DEFAULT_CONF['sasl.username'] = KAFKA_SASL_USERNAME
    DEFAULT_CONF['sasl.password'] = KAFKA_SASL_PASSWORD

def _test_shim():
    return


def wait_for_topic(consumer: Consumer, topic: str):
    """
    Wait for the existence of the topic before proceeding.

    Parameters
    ----------
    consumer : Kafka consumer instance.

    topic : The topic to wait for.
    """
    while True:
        logger.info('checking topic existence')
        topics = consumer.list_topics().topics
        if topic not in topics:
            logger.warning(f'Topic {topic} does not exist yet, sleeping for a while')
            _test_shim()
            sleep(1)
            continue
        break


def handle_kafka_error(error, msg):
    """
    Handle the error message from Kafka.

    Parameters
    ----------
    error : Error message from Kafka.

    msg : Message from Kafka.
    """
    if error.code() == KafkaError._PARTITION_EOF:
        logger.info('%% %s [%d] reached end at offset %d\n' % (msg.topic(), msg.partition(), msg.offset()))
    elif error.code() == KafkaError._UNKNOWN_TOPIC:
        logger.info('Topic doesnt exist yet, sleeping')
        sleep(1)
    elif error:
        logger.warning(f'Error found. This is my error and I dont know what to do, so Im crashing to bring it to your attention: {error}')


def get_bare_consumer(group_id: str = None, conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
    if group_id is not None:
        conf['group.id'] = group_id
    return Consumer(conf)


def fetch_work(topic : Union[str,List[str]], serializer_class: 'Protobuf', message_type: Type[NamedTuple], group_id: str = None, consumer: Consumer = None) -> Generator[Type[NamedTuple], None, None]:
    """
    BYOSerializers: Fetches work from Kafka, deserializes it, and results in a populated local message_type NamedTuple.

    Parameters
    ----------
    serializer_class : Protobuf serializer class.

    message_type : NamedTuple subclass. Needs to have a `from_protobuf` method.
    """
    logger.info('initializing consumer')
    if consumer is None:
        consumer = get_bare_consumer(group_id=group_id)
    try:
        signal.signal(signal.SIGTERM, lambda *args: consumer.close())
        signal.signal(signal.SIGINT, lambda *args: consumer.close())
    except ValueError:
        logging.warning('Running in debug? Cannot attach singal to non-main thread of interpreter.')
    wait_for_topic(consumer, topic)

    logger.info(f'subscribing to topic: {topic}')
    if type(topic) == list:
        topics = topic
    else:
        topics = [topic]
    consumer.subscribe(topics)
    logger.info('kicking off loop')
    while True:
        try:
            msg = consumer.poll(timeout=1.0)
        except RuntimeError:
            # Already closed due to sigterm or sigint,
            # so call it quits
            break
        if msg is None:
            continue
        error = msg.error()
        if error:
            handle_kafka_error(error, msg)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            yield message_type.from_protobuf(buffer)


def fetch_work_with_context(topic : Union[str,List[str]], serializer_class: 'Protobuf', message_type: Type[NamedTuple], group_id: str = None, consumer: Consumer = None) -> Generator[MessageContext, None, None]:
    """
    Enhanced version of fetch_work that returns MessageContext with headers and trace info.
    
    This function yields MessageContext objects that include:
    - data: The deserialized message (backward compatible)
    - headers: Raw Kafka headers
    - trace_context: OTEL trace headers (if present)
    - metadata: Topic, partition, offset, timestamp, key
    
    Parameters
    ----------
    topic : str or List[str]
        Topic name(s) to subscribe to
    serializer_class : Protobuf class
        Protobuf message class for deserialization  
    message_type : Type[NamedTuple]
        NamedTuple subclass with from_protobuf method
    group_id : str, optional
        Consumer group ID
    consumer : Consumer, optional
        Pre-configured consumer instance
        
    Yields
    ------
    MessageContext
        Message context with data, headers, and metadata
    """
    logger.info('initializing consumer with context')
    if consumer is None:
        consumer = get_bare_consumer(group_id=group_id)
    try:
        signal.signal(signal.SIGTERM, lambda *args: consumer.close())
        signal.signal(signal.SIGINT, lambda *args: consumer.close())
    except ValueError:
        logging.warning('Running in debug? Cannot attach singal to non-main thread of interpreter.')
    wait_for_topic(consumer, topic)

    logger.info(f'subscribing to topic: {topic}')
    if type(topic) == list:
        topics = topic
    else:
        topics = [topic]
    consumer.subscribe(topics)
    logger.info('kicking off loop with context')
    while True:
        try:
            msg = consumer.poll(timeout=1.0)
        except RuntimeError:
            # Already closed due to sigterm or sigint,
            # so call it quits
            break
        if msg is None:
            continue
        error = msg.error()
        if error:
            handle_kafka_error(error, msg)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            message_data = message_type.from_protobuf(buffer)
            
            # Extract headers and trace context
            headers = extract_headers_from_kafka_message(msg)
            trace_context = extract_trace_context(headers)
            
            # Create context with all metadata
            context = MessageContext(
                data=message_data,
                headers=headers,
                trace_context=trace_context,
                topic=msg.topic(),
                partition=msg.partition(),
                offset=msg.offset(),
                timestamp=msg.timestamp(),
                key=msg.key()
            )
            
            yield context


def get_producer(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return Producer(conf)


def produce_with_headers(producer: Producer, topic: str, value: bytes, key: Optional[str] = None, 
                        headers: Optional[Dict[str, Any]] = None, **kwargs):
    """
    Produce a message with optional headers.
    
    Parameters
    ----------
    producer : Producer
        Kafka producer instance
    topic : str
        Topic to produce to
    value : bytes
        Message value (serialized)
    key : str, optional
        Message key
    headers : Dict[str, Any], optional
        Headers to include with the message (str values will be encoded to bytes)
    **kwargs
        Additional arguments passed to producer.produce()
    """
    kafka_headers = None
    if headers:
        kafka_headers = []
        for k, v in headers.items():
            if isinstance(v, str):
                v = v.encode('utf-8')
            kafka_headers.append((k, v))
    
    producer.produce(topic, value=value, key=key, headers=kafka_headers, **kwargs)


def get_admin_client(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return AdminClient(conf)


# =============================================================================
# SQS Support (ElasticMQ locally, AWS SQS in production)
# =============================================================================

# SQS Configuration
SQS_ENDPOINT = os.environ.get('SQS_ENDPOINT')  # http://elasticmq:9324 locally, None in prod
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')

# Cache for SQS client
_sqs_client = None


def _get_sqs_client():
    """Get or create SQS client (cached)."""
    global _sqs_client
    if _sqs_client is None:
        if not HAS_BOTO3:
            raise ImportError("boto3 is required for SQS support. Install with: pip install boto3")
        if SQS_ENDPOINT:
            # Local ElasticMQ - use dummy credentials
            _sqs_client = boto3.client(
                'sqs',
                endpoint_url=SQS_ENDPOINT,
                region_name=AWS_REGION,
                aws_access_key_id='x',
                aws_secret_access_key='x'
            )
        else:
            # AWS SQS - use IAM credentials from environment/instance role
            _sqs_client = boto3.client('sqs', region_name=AWS_REGION)
    return _sqs_client


def _get_queue_url(queue_name: str) -> str:
    """
    Get queue URL from environment variable.

    Queue names use hyphens (SQS convention), env vars use underscores:
    - queue_name: 'video-received'
    - env var: SQS_QUEUE_VIDEO_RECEIVED
    """
    env_key = f"SQS_QUEUE_{queue_name.upper().replace('-', '_')}"
    url = os.environ.get(env_key)
    if not url:
        raise ValueError(f"Queue URL not found. Set {env_key} environment variable.")
    return url


def send_message(queue_name: str, body: dict, headers: Optional[Dict[str, str]] = None):
    """
    Send a JSON message to an SQS queue.

    Parameters
    ----------
    queue_name : str
        Queue name (e.g., 'video-received')
    body : dict
        Message body (will be JSON serialized)
    headers : dict, optional
        Message attributes (for OTEL trace propagation, etc.)
    """
    client = _get_sqs_client()
    queue_url = _get_queue_url(queue_name)

    msg_attrs = {}
    if headers:
        for k, v in headers.items():
            msg_attrs[k] = {'DataType': 'String', 'StringValue': str(v)}

    kwargs = {
        'QueueUrl': queue_url,
        'MessageBody': json.dumps(body),
    }
    if msg_attrs:
        kwargs['MessageAttributes'] = msg_attrs

    response = client.send_message(**kwargs)
    logger.debug(f"Sent message to {queue_name}: {response.get('MessageId')}")
    return response


def fetch_work_sqs(queue_name: str, visibility_timeout: int = 300) -> Generator[dict, None, None]:
    """
    Fetch work from an SQS queue, yielding JSON message bodies.

    This is the SQS equivalent of fetch_work() but returns dicts instead of protobuf.
    Messages are automatically deleted after being yielded.

    Parameters
    ----------
    queue_name : str
        Queue name (e.g., 'video-received')
    visibility_timeout : int
        How long the message is hidden from other consumers (default: 300s)

    Yields
    ------
    dict
        Parsed JSON message body
    """
    client = _get_sqs_client()
    queue_url = _get_queue_url(queue_name)

    logger.info(f"Starting SQS consumer for queue: {queue_name}")

    while True:
        try:
            response = client.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=1,
                WaitTimeSeconds=20,  # Long polling
                VisibilityTimeout=visibility_timeout,
                MessageAttributeNames=['All']
            )
        except Exception as e:
            logger.error(f"Error receiving message: {e}")
            sleep(5)
            continue

        messages = response.get('Messages', [])
        if not messages:
            continue

        for msg in messages:
            try:
                body = json.loads(msg['Body'])
                logger.info(f"Found work to do! MessageId: {msg['MessageId']}")

                yield body

                # Delete message after successful processing
                client.delete_message(
                    QueueUrl=queue_url,
                    ReceiptHandle=msg['ReceiptHandle']
                )
                logger.debug(f"Deleted message: {msg['MessageId']}")

            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse message body as JSON: {e}")
                # Don't delete - will retry after visibility timeout
            except Exception as e:
                logger.error(f"Error processing message: {e}")
                # Don't delete - will retry after visibility timeout


def fetch_work_sqs_with_context(queue_name: str, visibility_timeout: int = 300) -> Generator[MessageContext, None, None]:
    """
    Fetch work from an SQS queue, yielding MessageContext with headers and trace info.

    This is the SQS equivalent of fetch_work_with_context().
    Messages are automatically deleted after being yielded.

    Parameters
    ----------
    queue_name : str
        Queue name (e.g., 'video-received')
    visibility_timeout : int
        How long the message is hidden from other consumers (default: 300s)

    Yields
    ------
    MessageContext
        Message context with data (dict), headers, and trace_context
    """
    client = _get_sqs_client()
    queue_url = _get_queue_url(queue_name)

    logger.info(f"Starting SQS consumer with context for queue: {queue_name}")

    while True:
        try:
            response = client.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=1,
                WaitTimeSeconds=20,  # Long polling
                VisibilityTimeout=visibility_timeout,
                MessageAttributeNames=['All']
            )
        except Exception as e:
            logger.error(f"Error receiving message: {e}")
            sleep(5)
            continue

        messages = response.get('Messages', [])
        if not messages:
            continue

        for msg in messages:
            try:
                body = json.loads(msg['Body'])
                logger.info(f"Found work to do! MessageId: {msg['MessageId']}")

                # Extract headers from SQS MessageAttributes
                headers = {}
                msg_attrs = msg.get('MessageAttributes', {})
                for k, v in msg_attrs.items():
                    if v.get('DataType') == 'String':
                        headers[k] = v.get('StringValue', '').encode('utf-8')

                # Extract OTEL trace context
                trace_context = extract_trace_context(headers)

                context = MessageContext(
                    data=body,  # dict instead of protobuf
                    headers=headers,
                    trace_context=trace_context,
                    topic=queue_name,  # Use queue_name as "topic" for compatibility
                    partition=None,
                    offset=None,
                    timestamp=None,
                    key=None
                )

                yield context

                # Delete message after successful processing
                client.delete_message(
                    QueueUrl=queue_url,
                    ReceiptHandle=msg['ReceiptHandle']
                )
                logger.debug(f"Deleted message: {msg['MessageId']}")

            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse message body as JSON: {e}")
            except Exception as e:
                logger.error(f"Error processing message: {e}")
