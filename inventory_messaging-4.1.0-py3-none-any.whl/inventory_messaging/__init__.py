import os
import socket
from typing import NamedTuple, Type, Generator, Union, List, Dict, Optional, Any
import logging
from time import sleep
import signal
from dataclasses import dataclass

from confluent_kafka import Producer, Consumer, KafkaException, KafkaError, Message
from confluent_kafka.admin import AdminClient, NewTopic

logger = logging.getLogger(__name__)

KAFKA_HOST = os.environ.get('KAFKA_HOST', 'kafka')
KAFKA_PORT = os.environ.get('KAFKA_PORT', '9094')
KAFKA_ADDRESSES = os.environ.get('KAFKA_ADDRESS', f'{KAFKA_HOST}:{KAFKA_PORT}')
KAFKA_GROUP_ID = os.environ.get('KAFKA_GROUP_ID', 'default')
KAFKA_OFFSET = os.environ.get('KAFKA_OFFSET', 'latest')
KAFKA_SASL_USERNAME = os.environ.get('KAFKA_SASL_USERNAME')
KAFKA_SASL_PASSWORD = os.environ.get('KAFKA_SASL_PASSWORD')

@dataclass
class MessageContext:
    """Rich context for consumed messages with backward compatibility"""
    data: Any  # The deserialized protobuf data
    headers: Dict[str, bytes]  # Raw Kafka headers
    trace_context: Optional[Dict[str, str]] = None  # OTEL trace headers
    topic: Optional[str] = None
    partition: Optional[int] = None
    offset: Optional[int] = None
    timestamp: Optional[int] = None
    key: Optional[bytes] = None
    
    def __getattr__(self, name):
        """Backward compatibility - delegate to data object"""
        return getattr(self.data, name)
    
    def __iter__(self):
        """Support tuple unpacking for backward compatibility"""
        return iter(self.data)


def extract_headers_from_kafka_message(msg: Message) -> Dict[str, bytes]:
    """Extract headers from Kafka message as dict of bytes."""
    headers = {}
    if msg.headers():
        for key, value in msg.headers():
            if value is not None:
                headers[key] = value
    return headers


def extract_trace_context(headers: Dict[str, bytes]) -> Optional[Dict[str, str]]:
    """Extract OTEL trace context from headers."""
    trace_headers = {}
    # Common OTEL trace propagation headers
    trace_keys = ['traceparent', 'tracestate', 'baggage']
    
    for key, value in headers.items():
        if key.lower() in trace_keys:
            try:
                trace_headers[key] = value.decode('utf-8')
            except UnicodeDecodeError:
                logger.warning(f"Failed to decode trace header {key}")
    
    return trace_headers if trace_headers else None


__ALL__ = ['fetch_work', 'get_producer', 'MessageContext', 'fetch_work_with_context', 'produce_with_headers']


DEFAULT_CONF = {
    'bootstrap.servers': KAFKA_ADDRESSES,  # 'domain:port' or 'domain1:port,domain2:port,domain3:port'
    'client.id': socket.gethostname(),
    'group.id': KAFKA_GROUP_ID,
    'auto.offset.reset': KAFKA_OFFSET,
}
if KAFKA_SASL_USERNAME and KAFKA_SASL_PASSWORD:
    DEFAULT_CONF['sasl.mechanisms'] = 'SCRAM-SHA-512'
    DEFAULT_CONF['security.protocol'] = 'SASL_SSL'
    DEFAULT_CONF['sasl.username'] = KAFKA_SASL_USERNAME
    DEFAULT_CONF['sasl.password'] = KAFKA_SASL_PASSWORD

def _test_shim():
    return


def wait_for_topic(consumer: Consumer, topic: str):
    """
    Wait for the existence of the topic before proceeding.

    Parameters
    ----------
    consumer : Kafka consumer instance.

    topic : The topic to wait for.
    """
    while True:
        logger.info('checking topic existence')
        topics = consumer.list_topics().topics
        if topic not in topics:
            logger.warning(f'Topic {topic} does not exist yet, sleeping for a while')
            _test_shim()
            sleep(1)
            continue
        break


def handle_kafka_error(error, msg):
    """
    Handle the error message from Kafka.

    Parameters
    ----------
    error : Error message from Kafka.

    msg : Message from Kafka.
    """
    if error.code() == KafkaError._PARTITION_EOF:
        logger.info('%% %s [%d] reached end at offset %d\n' % (msg.topic(), msg.partition(), msg.offset()))
    elif error.code() == KafkaError._UNKNOWN_TOPIC:
        logger.info('Topic doesnt exist yet, sleeping')
        sleep(1)
    elif error:
        logger.warning(f'Error found. This is my error and I dont know what to do, so Im crashing to bring it to your attention: {error}')


def get_bare_consumer(group_id: str = None, conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
    if group_id is not None:
        conf['group.id'] = group_id
    return Consumer(conf)


def fetch_work(topic : Union[str,List[str]], serializer_class: 'Protobuf', message_type: Type[NamedTuple], group_id: str = None, consumer: Consumer = None) -> Generator[Type[NamedTuple], None, None]:
    """
    BYOSerializers: Fetches work from Kafka, deserializes it, and results in a populated local message_type NamedTuple.

    Parameters
    ----------
    serializer_class : Protobuf serializer class.

    message_type : NamedTuple subclass. Needs to have a `from_protobuf` method.
    """
    logger.info('initializing consumer')
    if consumer is None:
        consumer = get_bare_consumer(group_id=group_id)
    try:
        signal.signal(signal.SIGTERM, lambda *args: consumer.close())
        signal.signal(signal.SIGINT, lambda *args: consumer.close())
    except ValueError:
        logging.warning('Running in debug? Cannot attach singal to non-main thread of interpreter.')
    wait_for_topic(consumer, topic)

    logger.info(f'subscribing to topic: {topic}')
    if type(topic) == list:
        topics = topic
    else:
        topics = [topic]
    consumer.subscribe(topics)
    logger.info('kicking off loop')
    while True:
        try:
            msg = consumer.poll(timeout=1.0)
        except RuntimeError:
            # Already closed due to sigterm or sigint,
            # so call it quits
            break
        if msg is None:
            continue
        error = msg.error()
        if error:
            handle_kafka_error(error, msg)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            yield message_type.from_protobuf(buffer)


def fetch_work_with_context(topic : Union[str,List[str]], serializer_class: 'Protobuf', message_type: Type[NamedTuple], group_id: str = None, consumer: Consumer = None) -> Generator[MessageContext, None, None]:
    """
    Enhanced version of fetch_work that returns MessageContext with headers and trace info.
    
    This function yields MessageContext objects that include:
    - data: The deserialized message (backward compatible)
    - headers: Raw Kafka headers
    - trace_context: OTEL trace headers (if present)
    - metadata: Topic, partition, offset, timestamp, key
    
    Parameters
    ----------
    topic : str or List[str]
        Topic name(s) to subscribe to
    serializer_class : Protobuf class
        Protobuf message class for deserialization  
    message_type : Type[NamedTuple]
        NamedTuple subclass with from_protobuf method
    group_id : str, optional
        Consumer group ID
    consumer : Consumer, optional
        Pre-configured consumer instance
        
    Yields
    ------
    MessageContext
        Message context with data, headers, and metadata
    """
    logger.info('initializing consumer with context')
    if consumer is None:
        consumer = get_bare_consumer(group_id=group_id)
    try:
        signal.signal(signal.SIGTERM, lambda *args: consumer.close())
        signal.signal(signal.SIGINT, lambda *args: consumer.close())
    except ValueError:
        logging.warning('Running in debug? Cannot attach singal to non-main thread of interpreter.')
    wait_for_topic(consumer, topic)

    logger.info(f'subscribing to topic: {topic}')
    if type(topic) == list:
        topics = topic
    else:
        topics = [topic]
    consumer.subscribe(topics)
    logger.info('kicking off loop with context')
    while True:
        try:
            msg = consumer.poll(timeout=1.0)
        except RuntimeError:
            # Already closed due to sigterm or sigint,
            # so call it quits
            break
        if msg is None:
            continue
        error = msg.error()
        if error:
            handle_kafka_error(error, msg)
        else:
            logger.info('Found work to do!')
            data = msg.value()
            buffer = serializer_class.FromString(data)
            message_data = message_type.from_protobuf(buffer)
            
            # Extract headers and trace context
            headers = extract_headers_from_kafka_message(msg)
            trace_context = extract_trace_context(headers)
            
            # Create context with all metadata
            context = MessageContext(
                data=message_data,
                headers=headers,
                trace_context=trace_context,
                topic=msg.topic(),
                partition=msg.partition(),
                offset=msg.offset(),
                timestamp=msg.timestamp(),
                key=msg.key()
            )
            
            yield context


def get_producer(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return Producer(conf)


def produce_with_headers(producer: Producer, topic: str, value: bytes, key: Optional[str] = None, 
                        headers: Optional[Dict[str, Any]] = None, **kwargs):
    """
    Produce a message with optional headers.
    
    Parameters
    ----------
    producer : Producer
        Kafka producer instance
    topic : str
        Topic to produce to
    value : bytes
        Message value (serialized)
    key : str, optional
        Message key
    headers : Dict[str, Any], optional
        Headers to include with the message (str values will be encoded to bytes)
    **kwargs
        Additional arguments passed to producer.produce()
    """
    kafka_headers = None
    if headers:
        kafka_headers = []
        for k, v in headers.items():
            if isinstance(v, str):
                v = v.encode('utf-8')
            kafka_headers.append((k, v))
    
    producer.produce(topic, value=value, key=key, headers=kafka_headers, **kwargs)


def get_admin_client(conf=None):
    if conf is None:
        conf = DEFAULT_CONF.copy()
        del conf['group.id']
        del conf['auto.offset.reset']
    return AdminClient(conf)
