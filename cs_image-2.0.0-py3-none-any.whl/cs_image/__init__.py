from logging import getLogger
from pathlib import Path
import tempfile
from typing import NamedTuple, Optional

import boto3

from .imagemessage_pb2 import ImageMessage

logger = getLogger(__name__)


class ImageData(NamedTuple):
    id: str
    video_id: str
    s3_url: str
    frame_count: int
    object_id: Optional[str]
    object_type: str

    @classmethod
    def from_protobuf(cls, message: ImageMessage):
        """Required API for fetch_work system."""
        return ImageData(
            id=message.id,
            video_id=message.video_id,
            s3_url=message.s3_url,
            frame_count=message.frame_count,
            object_id=message.object_id if message.object_id else None,
            object_type=message.object_type,
        )

    def to_protobuf(self):
        return ImageMessage(
            id=self.id,
            video_id=self.video_id,
            s3_url=self.s3_url,
            frame_count=self.frame_count,
            object_id=self.object_id if self.object_id else None,
            object_type=self.object_type,
        )

    def __str__(self):

        return f'ImageData(id={self.id}, s3_url={self.s3_url}, {self.object_type}_id={self.object_id}, frame_count={self.frame_count})'

