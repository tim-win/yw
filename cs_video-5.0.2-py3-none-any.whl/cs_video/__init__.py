from logging import getLogger
from pathlib import Path
import tempfile
from typing import NamedTuple, Optional

import boto3

from .videomessage_pb2 import VideoMessage

logger = getLogger(__name__)


class VideoData(NamedTuple):
    id: str
    s3_url: str
    object_id: Optional[str]
    object_type: str

    @classmethod
    def from_protobuf(cls, message: VideoMessage):
        """Required API for fetch_work system."""
        return VideoData(
            id=message.id,
            s3_url=message.s3_url,
            object_id=message.object_id if message.object_id else None,
            object_type=message.object_type,
        )

    def to_protobuf(self):
        return VideoMessage(
            id=self.id,
            s3_url=self.s3_url,
            object_id=self.object_id,
            object_type=self.object_type,
        )

    def __str__(self):
        id_string = f'{self.object_type}_id={self.object_id}'
        return f'VideoData(id={self.id}, s3_url={self.s3_url}, {id_string})'


def copy_to_local(s3_handle: str) -> Path:
    logger.info(f'Copying {s3_handle} to local storage')
    object_path = Path('/'.join(s3_handle.split('/')[3:]).split('?')[0])
    bucket_name = s3_handle.split('/')[2].split('.')[0]
    tempdir = tempfile.mkdtemp()
    local_target = Path(tempdir) / object_path.name
    boto3.client(  # assume creds are available in environment
        's3',
    ).download_file(
        bucket_name,
        f'{object_path}',
        local_target
    )
    return local_target
